﻿using CsvHelper.Configuration;
using CsvHelper.Configuration.Attributes;

namespace PizzaAPI.Models
{
    public class Pizza
    {
        [Index(0)]
        public string Id { get; set; }

        [Index(1)]
        public string Type { get; set; }

        [Index(2)]
        public string Size { get; set; }

        [Index(3)]
        public double Price { get; set; }

    }

    public sealed class PizzaMap : ClassMap<Pizza>
    {
        public PizzaMap()
        {
            Map(x => x.Id).Name("Id").Index(0);
            Map(x => x.Type).Name("Type").Index(1);
            Map(x => x.Size).Name("Size").Index(2);
            Map(x => x.Price).Name("Price").Index(3);
        }
    }
}
