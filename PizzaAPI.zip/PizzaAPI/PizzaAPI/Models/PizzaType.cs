﻿using CsvHelper.Configuration;
using CsvHelper.Configuration.Attributes;

namespace PizzaAPI.Models
{
    public class PizzaType
    {
        [Index(0)]
        public string Id { get; set; }

        [Index(1)]
        public string Name { get; set; }

        [Index(2)]
        public string Category { get; set; }

        [Index(3)]
        public string Ingredients { get; set; }
    }

    public sealed class PizzaTypeMap : ClassMap<PizzaType>
    {
        public PizzaTypeMap()
        {
            Map(x => x.Id).Name("Id").Index(0);
            Map(x => x.Name).Name("Name").Index(1);
            Map(x => x.Category).Name("Category").Index(2);
            Map(x => x.Ingredients).Name("Ingredients").Index(3);
        }
    }
}
