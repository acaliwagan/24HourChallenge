﻿using CsvHelper.Configuration;
using CsvHelper.Configuration.Attributes;

namespace PizzaAPI.Models
{
    public class OrderDetails
    {
        [Index(0)]
        public int Id { get; set; }

        [Index(1)]
        public int OrderId { get; set; }

        [Index(2)]
        public string PizzaId { get; set; }

        [Index(3)]
        public int Quantity { get; set; }
    }

    public sealed class OrderDetailsMap : ClassMap<OrderDetails>
    {
        public OrderDetailsMap()
        {
            Map(x => x.Id).Name("Id").Index(0);
            Map(x => x.OrderId).Name("OrderId").Index(1);
            Map(x => x.PizzaId).Name("PizzaId").Index(2);
            Map(x => x.Quantity).Name("Quantity").Index(3);
        }
    }
}
