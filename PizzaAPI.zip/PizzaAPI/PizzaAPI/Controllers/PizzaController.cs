﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PizzaAPI.Models;
using PizzaAPI.Data;
using Newtonsoft.Json;
using CsvHelper;
using System.IO;
using System.Globalization;
using System.Data;
using CsvHelper.Configuration;
using System.Text;

namespace PizzaAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PizzaController : ControllerBase
    {
        private readonly ApiContext _context;

        public PizzaController(ApiContext context) 
        {
            _context = context;
        }

        #region Pizza
        [HttpPost]
        public async Task AddPizza(Pizza pizza)
        {
            if (!string.IsNullOrEmpty(pizza.Id))
            {
                var pizzaInDb = _context.Pizzas.Find(pizza.Id);
                if (pizzaInDb == null)
                    _context.Pizzas.Add(pizza);
                else
                    pizzaInDb = pizza;
            }

            _context.SaveChanges();
        }

        [HttpPost]
        public async Task AddPizzas(string filepath)
        {
            using (var reader = new StreamReader(filepath))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {

                var pizzas = csv.GetRecords<Pizza>();
                foreach (var pizza in pizzas)
                {
                    await AddPizza(pizza);
                }
            }
        }

        [HttpGet]
        public JsonResult GetPizza(string id)
        {
            var result = _context.Pizzas.Find(id);

            if (result == null)
                return new JsonResult(NotFound());

            return new JsonResult(Ok(result));
        }

        [HttpGet]
        public JsonResult GetAllPizzas()
        {
            var result = _context.Pizzas.ToList();

            return new JsonResult(Ok(result));
        }

        [HttpDelete]
        public JsonResult DeletePizza(string id)
        {
            var result = _context.Pizzas.Find(id);

            if (result == null)
                return new JsonResult(NotFound());

            _context.Pizzas.Remove(result);
            _context.SaveChanges();

            return new JsonResult(NoContent());
        }
        #endregion

        #region Order
        [HttpPost]
        public async Task AddOrder(Orders order)
        {
            if (order.Id > 0)
            {
                _context.Orders.Add(order);
            }
            else
            {
                var ordersInDb = _context.Orders.Find(order.Id);
                ordersInDb = order;
            }

            _context.SaveChanges();

        }

        [HttpPost]
        public async Task AddOrders(string filepath)
        {
            using (var reader = new StreamReader(filepath))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {

                var orders = csv.GetRecords<Orders>();
                foreach (var order in orders)
                {
                    await AddOrder(order);
                }
            }
        }

        [HttpGet]
        public int CountOrders()
        {
            return _context.Orders.ToList().Count();
        }

        [HttpGet]
        public int CountOrdersOnDate(string date)
        {
            return _context.Orders.ToList().Where(d => d.Date.ToString("yyyy-MM-dd") == date).Count();
        }

        [HttpGet]
        public JsonResult GetAllOrders()
        {
            var result = _context.Orders.ToList();

            return new JsonResult(Ok(result));
        }

        [HttpGet]
        public JsonResult GetOrder(int id)
        {
            var result = _context.Orders.Find(id);

            if (result == null)
                return new JsonResult(NotFound());

            return new JsonResult(Ok(result));
        }

        [HttpDelete]
        public JsonResult DeleteOrder(int id)
        {
            var result = _context.Orders.Find(id);

            if (result == null)
                return new JsonResult(NotFound());

            _context.Orders.Remove(result);
            _context.SaveChanges();

            return new JsonResult(NoContent());
        }
        #endregion

        #region Order Details
        [HttpPost]
        public async Task AddOrderDetails(OrderDetails orderDetails)
        {
            if (orderDetails.Id > 0)
            {
                _context.OrderDetails.Add(orderDetails);
            }
            else
            {
                var orderDetailsInDb = _context.OrderDetails.Find(orderDetails.Id);
                orderDetailsInDb = orderDetails;
            }

            _context.SaveChanges();

        }

        [HttpPost]
        public async Task AddOrdersDetails(string filepath)
        {
            using (var reader = new StreamReader(filepath))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {

                var orderDetails = csv.GetRecords<OrderDetails>();
                foreach (var orderDetail in orderDetails)
                {
                    await AddOrderDetails(orderDetail);
                }
            }
        }

        [HttpGet]
        public JsonResult GetAllOrderDetails()
        {
            var result = _context.OrderDetails.ToList();

            return new JsonResult(Ok(result));
        }

        [HttpGet]
        public JsonResult GetOrderDetails(int id)
        {
            var result = _context.OrderDetails.Find(id);

            if (result == null)
                return new JsonResult(NotFound());

            return new JsonResult(Ok(result));
        }

        [HttpGet]
        public int GetOrderTotalQuantity()
        {
            return _context.OrderDetails.Sum(x => Convert.ToInt32(x.Quantity));
        }

        [HttpGet]
        public int GetOrderByPizzaId(string pizzaId)
        {
            return _context.OrderDetails.Where(p => p.PizzaId == pizzaId).Count();
        }

        [HttpDelete]
        public JsonResult DeleteOrderDetail(int id)
        {
            var result = _context.OrderDetails.Find(id);

            if (result == null)
                return new JsonResult(NotFound());

            _context.OrderDetails.Remove(result);
            _context.SaveChanges();

            return new JsonResult(NoContent());
        }
        #endregion

        #region Pizza Types
        [HttpPost]
        public async Task AddPizzaType(PizzaType pizzaType)
        {
            if (!string.IsNullOrEmpty(pizzaType.Id))
            {
                _context.PizzaTypes.Add(pizzaType);
            }
            else
            {
                var orderDetailsInDb = _context.PizzaTypes.Find(pizzaType.Id);
                orderDetailsInDb = pizzaType;
            }

            _context.SaveChanges();

        }

        [HttpPost]
        public async Task AddPizzaTypes(string filepath)
        {
            using (var reader = new StreamReader(filepath))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {

                var pizzaTypes = csv.GetRecords<PizzaType>();
                foreach (var pizzaType in pizzaTypes)
                {
                    await AddPizzaType(pizzaType);
                }
            }
        }

        [HttpGet]
        public JsonResult GetAllPizzaTypes()
        {
            var result = _context.PizzaTypes.ToList();

            return new JsonResult(Ok(result));
        }

        [HttpGet]
        public JsonResult GetPizzaType(string id)
        {
            var result = _context.PizzaTypes.Find(id);

            if (result == null)
                return new JsonResult(NotFound());

            return new JsonResult(Ok(result));
        }

        [HttpGet]
        public int GetPizzaTypeById(string id)
        {
            return _context.PizzaTypes.Where(p => p.Id == id).Count();
        }

        [HttpDelete]
        public JsonResult DeletePizzaType(string id)
        {
            var result = _context.PizzaTypes.Find(id);

            if (result == null)
                return new JsonResult(NotFound());

            _context.PizzaTypes.Remove(result);
            _context.SaveChanges();

            return new JsonResult(NoContent());
        }
        #endregion

        #region Profits
        [HttpGet]
        public double GetProfitByPizza(string id)
        {
            var count = _context.OrderDetails.Where(p => p.PizzaId == id).Count();
            var pizza = _context.Pizzas.Find(id);
            return count * pizza.Price;
        }
        [HttpGet]
        public double GetProfitByDate(string date)
        {
            var totalProfit = 0.0;
            var orders = _context.Orders.ToList().Where(d => d.Date.ToString("yyyy-MM-dd") == date);

            foreach (var order in orders)
            {
                var orderDetails = _context.OrderDetails.Where(d => d.OrderId == order.Id);
                foreach(var orderDetail in orderDetails)
                {
                    var pizza = _context.Pizzas.Find(orderDetail.PizzaId);
                    totalProfit += pizza.Price * orderDetail.Quantity;
                }
            }

            return totalProfit;
        }

        [HttpGet]
        public double GetTotalProfits()
        {
            var totalProfit = 0.0;
            var orders = _context.OrderDetails.ToList();
            foreach (var order in orders)
            {
                var pizza = _context.Pizzas.Find(order.PizzaId);
                totalProfit += order.Quantity * pizza.Price;
            }

            return totalProfit;
        }

        #endregion
    }
}
