﻿using CsvHelper.Configuration;
using CsvHelper.Configuration.Attributes;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace PizzaAPI.Models
{
    public class Orders
    {
        [Index(0)]
        public int Id { get; set; }

        [Index(1)]
        public DateOnly Date { get; set; }

        [Index(2)]
        public string Time { get; set; }
    }

    public sealed class OrdersMap : ClassMap<Orders>
    {
        public OrdersMap()
        {
            Map(x => x.Id).Name("Id").Index(0);
            Map(x => x.Date).Name("Date").Index(1);
            Map(x => x.Time).Name("Time").Index(2);
        }
    }

    public sealed class DateOnlyJsonConverter : JsonConverter<DateOnly>
    {
        public override DateOnly Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            return DateOnly.FromDateTime(reader.GetDateTime());
        }

        public override void Write(Utf8JsonWriter writer, DateOnly value, JsonSerializerOptions options)
        {
            var isoDate = value.ToString("O");
            writer.WriteStringValue(isoDate);
        }
    }

    public sealed class TimeOnlyJsonConverter : JsonConverter<TimeOnly>
    {
        public override TimeOnly Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            return TimeOnly.FromDateTime(reader.GetDateTime());
        }

        public override void Write(Utf8JsonWriter writer, TimeOnly value, JsonSerializerOptions options)
        {
            var isoTime = value.ToString("O");
            writer.WriteStringValue(isoTime);
        }
    }
}
